<!DOCTYPE html>
<html>
<head>
<title>json</title>
<script src="jquery-3.6.1.min (1).js">
    </script>
<script>
    function  qq(){
        alert("zz");
        alert("qq");
        $.ajax({
         method:"get",
         ur1:"jason1-ajax.php",
         success:function(r){
            alert=("同步成功");
         }
        });
    } 
    </script>
</head>
<body>
    <h2>市場行銷</h2>
<ul>
<li onclick="alert('xx')">1</li>
<li>2</li>
</ul>





</body>
</html>