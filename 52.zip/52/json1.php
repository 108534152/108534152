<!DOCTYPE html>
<html>
<head>
<title>json</title>
</head>
<body>
    <?php
//https://data.gov.tw/dataset/8066
$抓到的資料=file_get_contents("https://data.coa.gov.tw/Service/OpenData/FromM/FarmTransData.aspx");
$資料=json_decode($抓到的資料,true);
//echo$資料 [0] ['作物名稱'];
$link=mysqli_connect('localhost','root','opendata',);
mysqli_set_charset($link,'utf8');
foreach($資料 as $v ){
    echo "作物名稱=$v[作物名稱]<br/>";
    mysqli_query($link,"INSERT INTOˋ花果ˋ(ˋ流水號ˋ,ˋ日期ˋ,ˋ名稱ˋ,ˋ平均價格ˋ,ˋ交易量ˋ)VALUES
    (NULL,'$v[交易日期]','$v[作物名稱]','$v[平均價]','$v[交易量]');");
}
?>

</body>
</html>
